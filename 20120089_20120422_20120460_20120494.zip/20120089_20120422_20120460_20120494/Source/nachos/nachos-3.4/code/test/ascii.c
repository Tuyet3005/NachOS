#include "syscall.h"

int
main()
{
	int i;
    PrintString("Bang ma ascii: \n");
	for (i = 0 ; i < 255 ; i++){
		PrintInt(i);
		PrintString(". ");
		PrintChar(i);
		PrintChar('\n');
	}
	Halt();
}
