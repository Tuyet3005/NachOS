#include "syscall.h" 
#include "copyright.h"
int main() 
{ 
    int result;
    result = ReadInt();
    PrintInt(result);
    Halt();
}

    
